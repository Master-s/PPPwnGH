PS4 Payload SDK
=================
An open source SDK for writing payloads for the PlayStation 4

## Chain of Development
[CTurt](https://github.com/CTurt/PS4-SDK) > [IDC](https://github.com/idc/ps4-payload-sdk) > [xvortex](https://github.com/xvortex/ps4-payload-sdk) > [stooged](https://github.com/stooged/ps4-payload-sdk) > [Scene-Collective](https://github.com/Scene-Collective/ps4-payload-sdk)

## Why?
Built with existing payload in mind and to be used in the autobuild system. Hopefully this is just a stop-gap until a full featured Mira release.
