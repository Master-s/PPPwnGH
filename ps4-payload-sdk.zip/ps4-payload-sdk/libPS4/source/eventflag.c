#include "syscall.h"

#include "eventflag.h"

SYSCALL(createEventFlag, 538);
SYSCALL(destroyEventFlag, 539);
