#include "debug.h"

int DEBUG_SOCK = -1;
