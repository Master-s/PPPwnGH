#include "syscall.h"

#include "unknown.h"

SYSCALL(unknownResourceCreate, 574);
SYSCALL(unknownResourceDestroy, 575);
