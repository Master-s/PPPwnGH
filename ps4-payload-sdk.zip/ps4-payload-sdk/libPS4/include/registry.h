#pragma once

#ifndef REGISTRY_H
#define REGISTRY_H

#include "types.h"

int registryCommand(int command);

#endif
