#pragma once

#ifndef UNKNOWN_H
#define UNKNOWN_H

#include "types.h"

int unknownResourceCreate(const char *name);
int unknownResourceDestroy(int unknownResource);

#endif
